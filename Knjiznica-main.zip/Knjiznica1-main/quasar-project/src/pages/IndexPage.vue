<template>
  <q-page class="flex flex-center">
    <img
      alt="Knjiznica slika"
      src="~assets/library.jpg"
      class="my-image"
    >
  </q-page>
</template>

<script setup>
// Ovdje možete dodati dodatne skripte ili logiku ako je potrebno
</script>

<style scoped>
.my-image {
  max-width: 100%;
  height: auto; /* Održava proporcije slike */
}
</style>
