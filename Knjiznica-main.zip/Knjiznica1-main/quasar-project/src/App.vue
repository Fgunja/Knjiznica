<template>
  <router-view />
</template>

<script setup>
defineOptions({
  name: 'App'
});
</script>
